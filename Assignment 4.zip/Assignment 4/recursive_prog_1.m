% This MATLAB code solves for the interest rate r in the equation:
% using two numerical methods: Newton-Raphson and Secant method

clear
clc

f = @(r) 10000000 * (1 + r).^12 - 15000000;     % Define the function to find root of: f(r) = Ugx10,000,000*(1+r)^12 - ugx15,000,000

tol = 1e-8;        % Tolerance for convergence (stop when |f(r)| < tol)
max_iter = 100;    % Maximum number of iterations to prevent infinite loops


fprintf('Find r: 15000 = 10000 × (1 + r)^12\n\n');     % Display the problem being solved

% NEWTON-RAPHSON METHOD
fprintf('NEWTON-RAPHSON:\n');

[root_n, iter_n] = newton_recursive(f, 0.03, tol, max_iter, 1);  % Call Newton-Raphson method with initial guess r = 0.03 (3%), Returns root and number of iterations

% SECANT METHOD
fprintf('\nSECANT:\n');

[root_s, iter_s] = secant_recursive(f, 0.02, 0.04, tol, max_iter, 1);  % Call Secant method with initial guesses r1 = 0.02, r2 = 0.04 (2% and 4%), Returns root and number of iterations

% DISPLAY FINAL RESULTS
fprintf('\nRESULTS:\n');
fprintf('Newton: r = %.6f%% (%d iter)\n', root_n*100, iter_n);% Convert decimal rate to percentage and display results
fprintf('Secant: r = %.6f%% (%d iter)\n', root_s*100, iter_s);

% NEWTON-RAPHSON FUNCTION
% Inputs: 
%   f - function handle
%   x - current guess
%   tol - tolerance
%   max_iter - maximum iterations allowed
%   iter - current iteration count
% Outputs:
%   root - found root
%   iter - total iterations used
function [root, iter] = newton_recursive(f, x, tol, max_iter, iter)
    
    if iter > max_iter, error('Max iter'); end    % Check if maximum iterations exceeded
    h = 1e-8;    % h is a small step for finite difference approximation
    x_new = x - f(x) / ((f(x + h) - f(x - h)) / (2 * h));   % Newton-Raphson update formula: x_new = x - f(x)/f'(x)
    fprintf('%2d: r = %.8f\n', iter, x_new);    % Display current iteration result
    % Check convergence criterion
    if abs(f(x_new)) < tol
        root = x_new;  % Return converged root
        return;
    end
    [root, iter] = newton_recursive(f, x_new, tol, max_iter, iter + 1);    % Recursive call for next iteration
end

% SECANT METHOD FUNCTION
% Inputs:
%   f - function handle
%   x0, x1 - two initial guesses
%   tol - tolerance
%   max_iter - maximum iterations allowed
%   iter - current iteration count
% Outputs:
%   root - found root
%   iter - total iterations used
function [root, iter] = secant_recursive(f, x0, x1, tol, max_iter, iter)
    % Check if maximum iterations exceeded
    if iter > max_iter, error('Max iter'); end
    % Secant method update formula: 
    % x2 = x1 - f(x1)*(x1 - x0)/(f(x1) - f(x0))
    x2 = x1 - f(x1) * (x1 - x0) / (f(x1) - f(x0));
    fprintf('%2d: r = %.8f\n', iter, x2);   % Display current iteration result
    % Check convergence criterion
    if abs(f(x2)) < tol
        root = x2;  % Return converged root
        return;
    end
    [root, iter] = secant_recursive(f, x1, x2, tol, max_iter, iter + 1);    % Recursive call for next iteration with updated guesses
end
% This MATLAB code compares the performance of recursive(rec) vs dynamic programming(dp)
% approaches for two problems: Knapsack(knap) and Fibonacci(fib)
clear; clc;

%% Knapsack Problem Functions

% Recursive Knapsack - solves problem by breaking into smaller subproblems
function max_val = knap_rec(w, v, cap, n)
    % Base case: no items or no capacity
    if n == 0 || cap == 0
        max_val = 0;
    % If current item is too heavy, skip it
    elseif w(n) > cap
        max_val = knap_rec(w, v, cap, n-1);
    else
        % Try including the current item
        include = v(n) + knap_rec(w, v, cap - w(n), n-1);
        % Try excluding the current item
        exclude = knap_rec(w, v, cap, n-1);
        % Choose the better option
        max_val = max(include, exclude);
    end
end

% Dynamic Programming Knapsack - uses table to store and reuse solutions
function max_val = knap_dp(w, v, cap)
    n = length(w);
    % Create DP table: rows = items, columns = capacities
    dp = zeros(n+1, cap+1);
    
    % Fill DP table iteratively
    for i = 1:n
        for j = 0:cap
            if w(i) > j
                % Can't include item i - carry forward previous solution
                dp(i+1, j+1) = dp(i, j+1);
            else
                % Choose max of including or excluding item i
                dp(i+1, j+1) = max(dp(i, j+1), v(i) + dp(i, j+1 - w(i)));
            end
        end
    end
    max_val = dp(n+1, cap+1);
end

%% Fibonacci Functions
% Fibonacci sequence: 1, 1, 2, 3, 5, 8, 13, ...

% Recursive Fibonacci
function f = fib_rec(n)
    if n <= 2
        f = 1;
    else
        % Recursively calculate previous two Fibonacci numbers
        f = fib_rec(n-1) + fib_rec(n-2);
    end
end

% Dynamic Programming Fibonacci - uses memoization to avoid redundant calculations
function f = fib_dp(n)
    if n <= 2
        f = 1;
        return;
    end
    
    % Initialize memoization array
    memo = zeros(1, n);
    memo(1) = 1;
    memo(2) = 1;
    
    % Build solution bottom-up
    for i = 3:n
        memo(i) = memo(i-1) + memo(i-2);
    end
    f = memo(n);
end
%% Test Knapsack - Compare performance on different problem sizes
fprintf('Knapsack Comparison\n');

% Test different problem sizes
sizes = [5, 10, 15, 20];
t_rec_knap = zeros(size(sizes));
t_dp_knap = zeros(size(sizes));

for i = 1:length(sizes)
    n = sizes(i);
    % Generate random weights and values
    w = randi([1, 20], 1, n);
    v = randi([10, 50], 1, n);
    % Set capacity to 60% of total weight
    cap = round(sum(w) * 0.6);
    
    % Time recursive solution
    tic; rec_val = knap_rec(w, v, cap, n); t_rec_knap(i) = toc;
    % Time Dynamic Programming solution
    tic; dp_val = knap_dp(w, v, cap); t_dp_knap(i) = toc;
    
    fprintf('n=%2d: Rec=%6.4fs (%2d), DP=%7.6fs (%2d)\n', ...
            n, t_rec_knap(i), rec_val, t_dp_knap(i), dp_val);
end

%% Test Fibonacci - Compare performance on different Fibonacci numbers
fprintf('\nFibonacci Comparison\n');

% Test different Fibonacci numbers
fib_n = 10:5:35;
t_rec_fib = zeros(size(fib_n));
t_dp_fib = zeros(size(fib_n));

for i = 1:length(fib_n)
    n = fib_n(i);
    
    % Time recursive solution
    tic; fib_rec(n); t_rec_fib(i) = toc;
    % Time Dynamic Programming solution
    tic; fib_dp(n); t_dp_fib(i) = toc;

    fprintf('n=%2d: Rec=%8.6fs, DP=%8.6fs\n', n, t_rec_fib(i), t_dp_fib(i));
end

%% Plot Results - Visualize the performance differences
% Knapsack timing comparison plot
figure;
plot(sizes, t_rec_knap * 1000, 'ro-', 'LineWidth', 2); hold on;
plot(sizes, t_dp_knap * 1000, 'bs-', 'LineWidth', 2);
xlabel('Number of Items'); ylabel('Time (ms)');
title('Knapsack: Timing Comparison'); 
legend('Recursive', 'Dynamic Programming'); grid on;

% Fibonacci timing comparison plot
figure;
plot(fib_n, t_rec_fib * 1000, 'ro-', 'LineWidth', 2); hold on;
plot(fib_n, t_dp_fib * 1000, 'bs-', 'LineWidth', 2);
xlabel('Fibonacci(n)'); ylabel('Time (ms)');
title('Fibonacci: Timing Comparison');
legend('Recursive', 'Dynamic Programming'); grid on;

% Knapsack speedup ratio plot
figure;
speedup_knap = t_rec_knap ./ t_dp_knap;
plot(sizes, speedup_knap, 'g^-', 'LineWidth', 2);
xlabel('Number of Items'); ylabel('Speedup Ratio');
title('Knapsack: Dynamic Programming Speedup'); grid on;

% Fibonacci speedup ratio plot
figure;
speedup_fib = t_rec_fib ./ t_dp_fib;
plot(fib_n, speedup_fib, 'g^-', 'LineWidth', 2);
xlabel('Fibonacci(n)'); ylabel('Speedup Ratio');
title('Fibonacci: Dynamic Programming Speedup'); grid on;
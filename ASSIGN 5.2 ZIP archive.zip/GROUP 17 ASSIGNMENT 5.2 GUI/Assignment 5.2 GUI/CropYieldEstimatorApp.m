classdef CropYieldEstimatorApp < handle
    % CROPPREDICTORAPP: A MATLAB GUI for crop yield prediction with visualization.
    
    properties
        Fig              % Main figure object
        YieldDataObj     % Handle to the loaded and preprocessed YieldData object
        CropModelObj     % Handle to the trained LinearRegressionCropModel object
        
        % UI Components
        CropDropdown
        TrainButton
        SummaryText
        PlotAxes         % Axes for plotting
        RainfallEdit
        PesticidesEdit
        TempEdit
        PredictButton
        ResultText
    end
    
    methods
        % Constructor (App Startup)
        function app = CropYieldEstimatorApp()
            % 1. Load Data and Initialize Backend
            app.YieldDataObj = YieldData('yield_df.csv'); 
            app.YieldDataObj = app.YieldDataObj.preprocessData();
            
            % 2. Build the User Interface
            app.createUI();
            
            % 3. Populate Crop Dropdown
            [~, ~, cropList] = app.YieldDataObj.getTrainingData(); 
            app.CropDropdown.Items = [{'Select Crop'}; cropList];
            
            % 4. Set Initial UI State
            app.TrainButton.Enable = 'off';
            app.PredictButton.Enable = 'off';
        end
        
        % UI Creation Function
        function createUI(app)
            % Adjust figure size to accommodate the plot
            app.Fig = uifigure('Name', 'Crop Yield Predictor', 'Position', [100 100 600 550]);
            
            % --- 1. Model Training & Diagnostics Panel (Adjusted Position/Size) ---
            TrainPanel = uipanel(app.Fig, 'Title', '1. Model Training & Diagnostics', 'Position', [20 250 560 300]);
            
            % Crop Selection and Train Button (Top Row)
            uilabel(TrainPanel, 'Position', [20 250 100 22], 'Text', 'Select Crop:');
            app.CropDropdown = uidropdown(TrainPanel, ...
                'Position', [120 250 180 22], ...
                'Items', {'Loading...'}, ...
                'ValueChangedFcn', @(src, event) app.CropDropdownValueChanged(src, event));
            
            app.TrainButton = uibutton(TrainPanel, 'push', ...
                'Position', [320 250 180 22], ...
                'Text', 'Train Model', ...
                'ButtonPushedFcn', @(src, event) app.TrainModelButtonPushed(src, event));
            
            % Summary Text (Below Top Row)
            uilabel(TrainPanel, 'Position', [20 220 100 22], 'Text', 'R-squared:');
            app.SummaryText = uilabel(TrainPanel, 'Position', [120 220 380 22], 'Text', 'No model trained.');

            % UIAxes for Plotting - **FIXED:** Removed invalid properties from constructor
            app.PlotAxes = uiaxes(TrainPanel, 'Position', [20 10 520 200]);

            % --- 2. Predict Yield Panel (Adjusted Position/Size) ---
            PredictPanel = uipanel(app.Fig, 'Title', '2. Predict Yield (hg/ha)', 'Position', [20 20 560 210]);
            
            % Input Fields
            uilabel(PredictPanel, 'Position', [20 140 150 22], 'Text', 'Rainfall (mm/year):');
            app.RainfallEdit = uieditfield(PredictPanel, 'numeric', 'Position', [180 140 100 22]);
            
            uilabel(PredictPanel, 'Position', [20 110 150 22], 'Text', 'Pesticides (tonnes):');
            app.PesticidesEdit = uieditfield(PredictPanel, 'numeric', 'Position', [180 110 100 22]);
            
            uilabel(PredictPanel, 'Position', [20 80 150 22], 'Text', 'Avg Temp (Celsius):');
            app.TempEdit = uieditfield(PredictPanel, 'numeric', 'Position', [180 80 100 22]);
            
            app.PredictButton = uibutton(PredictPanel, 'push', ...
                'Position', [350 110 150 50], ...
                'Text', 'Predict Yield', ...
                'ButtonPushedFcn', @(src, event) app.PredictYieldButtonPushed(src, event));
            
            % Result Display
            uilabel(PredictPanel, 'Position', [20 30 150 22], 'Text', 'Predicted Yield:');
            app.ResultText = uilabel(PredictPanel, 'Position', [180 30 300 22], 'Text', '---');
        end
        
        % Callbacks
        
        function CropDropdownValueChanged(app, src, ~)
            % Reset status when crop selection changes
            if strcmp(src.Value, 'Select Crop')
                app.TrainButton.Enable = 'off';
            else
                app.TrainButton.Enable = 'on';
            end
            app.SummaryText.Text = 'No model trained.';
            app.ResultText.Text = '---';
            app.PredictButton.Enable = 'off';
            cla(app.PlotAxes); % Clear the plot axes
        end
        
        function TrainModelButtonPushed(app, ~, ~)
            cropName = app.CropDropdown.Value;
            
            try
                % 1. Get filtered data for the selected crop
                [X_crop, Y_crop] = app.YieldDataObj.filterDataByCrop(cropName);
                
                % 2. Initialize and Train the Linear Regression Model
                app.CropModelObj = LinearRegressionCropModel(cropName);
                app.CropModelObj = app.CropModelObj.trainModel(X_crop, Y_crop); 
                
                % 3. Update UI
                rSquared = app.CropModelObj.Rsquared;
                app.SummaryText.Text = sprintf('%.4f', rSquared);
                app.PredictButton.Enable = 'on';

                % 4. Plotting Logic: Rainfall vs. Yield with Regression Line
                
                rainFeatureCol = 'average_rain_fall_mm_per_year';
                
                % Scatter plot of actual data
                scatter(app.PlotAxes, X_crop{:, rainFeatureCol}, Y_crop, 15, 'filled', ...
                    'MarkerFaceColor', [0.4 0.7 1.0], 'DisplayName', 'Actual Data');
                hold(app.PlotAxes, 'on');

                % Calculate prediction line range
                x_min = min(X_crop{:, rainFeatureCol});
                x_max = max(X_crop{:, rainFeatureCol});
                x_range = linspace(x_min, x_max, 100)';
                
                % Set other features (Pesticides and Temp) to their mean for plotting context
                pesticide_mean = mean(X_crop.pesticides_tonnes);
                temp_mean = mean(X_crop.avg_temp);
                
                % Create a prediction table for the range
                X_pred = table(x_range, repmat(pesticide_mean, 100, 1), repmat(temp_mean, 100, 1), ...
                    'VariableNames', {'average_rain_fall_mm_per_year', 'pesticides_tonnes', 'avg_temp'});
                
                % Predict the yield across the rainfall range
                Y_pred = app.CropModelObj.predictYield(X_pred);
                
                % Plot the regression line
                plot(app.PlotAxes, x_range, Y_pred, 'r-', 'LineWidth', 2, 'DisplayName', 'Regression Line');
                
                % **FIXED:** Setting title and labels using separate functions
                title(app.PlotAxes, sprintf('%s: Rainfall vs. Yield (R\xb2=%.4f)', cropName, rSquared));
                xlabel(app.PlotAxes, 'Rainfall (mm/year)');
                ylabel(app.PlotAxes, 'Yield (hg/ha)');
                legend(app.PlotAxes, 'show', 'Location', 'northwest');
                grid(app.PlotAxes, 'on');
                hold(app.PlotAxes, 'off');
                
            catch ME
                uialert(app.Fig, ME.message, 'Training Error');
                app.SummaryText.Text = 'Training Failed!';
                app.PredictButton.Enable = 'off';
                cla(app.PlotAxes);
            end
        end
        
        function PredictYieldButtonPushed(app, ~, ~)
            if isempty(app.CropModelObj)
                uialert(app.Fig, 'Please train a model first.', 'Prediction Error');
                return;
            end
            
            try
                % 1. Get input values
                rainfall = app.RainfallEdit.Value;
                pesticides = app.PesticidesEdit.Value;
                temp = app.TempEdit.Value;

                if isempty(rainfall) || isempty(pesticides) || isempty(temp)
                     uialert(app.Fig, 'Please enter values for all three inputs.', 'Input Error');
                     return;
                end
                
                % 2. Create the input table (X_new)
                X_new = table(rainfall, pesticides, temp, ...
                    'VariableNames', {'average_rain_fall_mm_per_year', 'pesticides_tonnes', 'avg_temp'});
                
                % 3. Predict Yield
                predictedYield = app.CropModelObj.predictYield(X_new); 
                
                % 4. Update UI
                resultStr = sprintf('%.2f hg/ha', predictedYield);
                app.ResultText.Text = resultStr;
                
            catch ME
                uialert(app.Fig, ME.message, 'Prediction Error');
                app.ResultText.Text = 'Prediction Failed!';
            end
        end
        
    end
end
classdef (Abstract) CropModel
    % CROPMODEL: Abstract base class for all crop yield estimation models.
    
    properties (SetAccess = private)
        CropType % Name of the crop the model is trained for.
    end
    
    properties (Access = protected)
        % Protected property for internal model structure (Encapsulation).
        ModelStructure
    end
    
    methods
        function obj = CropModel(cropType)
            % Constructor
            obj.CropType = cropType;
        end
        
        function displaySummary(obj)
            % Standard method to display model details.
            disp(['Model Type: ', class(obj)]);
            disp(['Crop: ', obj.CropType]);
        end
    end
    
    methods (Abstract)
        % Abstraction & Polymorphism: Methods must be implemented by concrete subclasses.
        
        % Abstract method: Trains the model on features X and target Y.
        obj = trainModel(obj, X, Y)
        
        % Abstract method: Predicts yield for new features X_new.
        predictedYield = predictYield(obj, X_new)
    end
end
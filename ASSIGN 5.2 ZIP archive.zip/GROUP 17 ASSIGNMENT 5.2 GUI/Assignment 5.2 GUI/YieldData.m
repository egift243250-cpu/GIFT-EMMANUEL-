classdef YieldData
    % YIELDDATA: Handles the loading, cleaning, and preparation of yield estimation data.
    
    properties (Access = private)
        % Encapsulation: 'Data' is protected from direct external modification.
        Data table
    end
    
    methods
        function obj = YieldData(fileName)
            % Constructor: Loads the data upon object creation.
            if nargin > 0
                obj = obj.loadData(fileName);
            end
        end
        
        function obj = loadData(obj, fileName)
            % Loads the dataset (assumed to be yield_df.csv, which is pre-merged).
            try
                disp(['Loading data from: ', fileName]);
                obj.Data = readtable(fileName);
            catch ME
                error('YieldData:LoadError', 'Could not load the data file: %s', ME.message);
            end
        end
        
        function obj = preprocessData(obj)
            % Data Cleaning and Feature Engineering (Abstraction of cleaning logic).
            disp('Preprocessing data...');
            
            % 1. Remove rows with missing values (NaNs in 'hg/ha_yield' or features)
            obj.Data = rmmissing(obj.Data);
            
            disp('Data preprocessing complete.');
        end
        
        function [X, Y, CropList] = getTrainingData(obj)
            % Provides the full preprocessed features (X) and target (Y) variables.
            
            if isempty(obj.Data)
                error('YieldData:NoData', 'Data has not been loaded or is empty.');
            end
            
            % Define features (X) and target (Y) based on yield_df.csv columns.
            FeatureCols = {'average_rain_fall_mm_per_year', 'pesticides_tonnes', 'avg_temp'};
            TargetCol = 'hg_ha_yield';
            
            % Abstraction: Only returns the necessary matrices, hiding table complexity.
            X = obj.Data(:, FeatureCols);
            Y = obj.Data{:, TargetCol};
            CropList = unique(obj.Data.Item);
        end
        
        % FIX: NEW PUBLIC METHOD to safely filter the data
        function [X_crop, Y_crop] = filterDataByCrop(obj, cropName)
            % Returns the features and target variables filtered for a specific crop.
            if isempty(obj.Data)
                error('YieldData:NoData', 'Data has not been loaded or is empty.');
            end
            
            cropIndex = strcmp(obj.Data.Item, cropName);
            
            % Define features (X) and target (Y)
            FeatureCols = {'average_rain_fall_mm_per_year', 'pesticides_tonnes', 'avg_temp'};
            TargetCol = 'hg_ha_yield';
            
            X_crop = obj.Data(cropIndex, FeatureCols);
            Y_crop = obj.Data{cropIndex, TargetCol};
        end
    end
end